module.exports = () => ({
  BOT_NAME: "Sword",
  OWNER_NAME: "Saint",
  MENU_STYLE: "fancy",
  SESSION_ID: "",
  OWNER_NUMBER: ""
});
