import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";
import QRCode from "qrcode";

const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors());
app.use(express.json());
const upload = multer({ dest: "uploads/" });

function makeSessionId() {
  const rand = Array.from({length:8}).map(()=> Math.random().toString(36).charAt(2)).join('').toUpperCase();
  return `Sword-ai${rand}`;
}

function writeConfig(sessionId, ownerNumber) {
  const cfgPath = path.join(process.cwd(), "config.js");
  const content = `module.exports = () => ({\n  BOT_NAME: "Sword",\n  OWNER_NAME: "Saint",\n  MENU_STYLE: "fancy",\n  SESSION_ID: "${sessionId}",\n  OWNER_NUMBER: "${ownerNumber}"\n});\n`;
  fs.writeFileSync(cfgPath, content, "utf-8");
  return true;
}

app.post("/api/session/pair", async (req, res) => {
  try {
    const phone = req.body && req.body.phone ? String(req.body.phone).trim() : "";
    if(!phone) return res.status(400).json({ message: "Phone required (body.phone)" });
    const sessionId = makeSessionId();
    const ok = writeConfig(sessionId, phone);
    if(!ok) return res.status(500).json({ message: "Failed to write config" });
    // create QR that encodes session and phone (JSON)
    const payload = JSON.stringify({ sessionId, phone });
    const qrDataUrl = await QRCode.toDataURL(payload);
    return res.json({ pairingCode: sessionId, sessionId, phone, qrDataUrl });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/session/qr", async (req, res) => {
  try {
    const sessionId = req.query.sessionId || "";
    const phone = req.query.phone || "";
    const payload = JSON.stringify({ sessionId, phone });
    const qrDataUrl = await QRCode.toDataURL(payload);
    return res.json({ qrDataUrl });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: "Server error" });
  }
});

// Minimal auth placeholders
app.post("/api/auth/register", (req, res) => { res.json({ message: "ok" }); });
app.post("/api/auth/login", (req, res) => { res.json({ token: "demo-token" }); });

// Plugin endpoints
app.post("/api/plugins/submit", upload.single("file"), (req, res) => {
  if(!req.file) return res.status(400).json({ message: "File required" });
  // move uploaded file to plugins folder
  const destDir = path.join(process.cwd(), "uploads");
  if(!fs.existsSync(destDir)) fs.mkdirSync(destDir);
  const dest = path.join(destDir, req.file.originalname || req.file.filename);
  fs.renameSync(req.file.path, dest);
  return res.json({ message: "Submitted", filename: req.file.originalname || req.file.filename });
});

app.get("/api/plugins", (req, res) => {
  const dir = path.join(process.cwd(), "uploads");
  const list = fs.existsSync(dir) ? fs.readdirSync(dir) : [];
  res.json(list);
});

app.post("/api/suggestions", (req, res) => {
  console.log("Suggestion received:", req.body);
  res.json({ message: "Suggestion received" });
});

app.listen(PORT, ()=> console.log("Sword Bot API running on", PORT));
