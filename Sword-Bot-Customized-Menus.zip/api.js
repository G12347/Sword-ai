
// Sword Bot API server using Express.js
import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";


/* --- Centralized, cleaner menu builder (inserted by assistant) --- */
async function buildCleanMenu({ config, types, prefix, m, commands, version }){
  const botName = (config && typeof config === 'function' && config().BOT_NAME) ? config().BOT_NAME : "Sword";
  const ownerName = (config && typeof config === 'function' && config().OWNER_NAME) ? config().OWNER_NAME : "Owner";
  const userName = (m && m.pushName) ? m.pushName : "User";
  const uptime = (typeof process !== 'undefined' && process.uptime) ? (function(){ const s = Math.floor(process.uptime()); const h = Math.floor(s/3600); const mm = Math.floor((s%3600)/60); const ss = s%60; return `${h}h ${mm}m ${ss}s`; })() : "N/A";
  const header = `=== ${botName} ===\\nOwner: ${ownerName}\\nUser: ${userName}\\nCommands: ${commands ? commands.length : 0}\\nUptime: ${uptime}\\nVersion: v${version || '1.0.0'}\\n\\n`;
  const sections = Object.keys(types || {}).map(type => {
    const cmds = (types[type] || []).map(c => `${prefix}${String(c).replace(/[^a-zA-Z0-9-+]/g,'')}`).join(', ');
    return `${type.toUpperCase()}:\\n${cmds}`;
  }).join('\\n\\n');
  const footer = `\\nTip: Use ${prefix}menu [category] for specific commands`;
  return header + (sections || "(no categories)") + footer;
}
/* --- end menu builder --- */




const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// For file uploads
const upload = multer({ dest: "uploads/" });

// Dummy in-memory DB for users and plugins
let users = [];
let plugins = [];
let pending = [];

// Session endpoints
app.post("/api/session/pair", (req,res)=>{
  const phone = req.body.phone;
  if(!phone) return res.status(400).json({message:"Phone required"});
  const code = Math.random().toString(36).substring(2,8).toUpperCase();
  return res.json({pairingCode: code});
});

app.get("/api/session/qr", (req,res)=>{
  // In real bot: generate QR. For now send dummy
  const dummy = "data:image/png;base64,";
  res.json({qrDataUrl: dummy});
});

// Auth endpoints
app.post("/api/auth/register", (req,res)=>{
  const {email,password} = req.body;
  if(!email || !password) return res.status(400).json({message:"Missing"});
  if(users.find(u=>u.email===email)) return res.status(400).json({message:"Exists"});
  users.push({email,password,admin:false});
  res.json({message:"Registered"});
});

app.post("/api/auth/login", (req,res)=>{
  const {email,password} = req.body;
  const user = users.find(u=>u.email===email && u.password===password);
  if(!user) return res.status(401).json({message:"Invalid"});
  // In real API, issue JWT. Here simple token
  const token = Buffer.from(email).toString("base64");
  res.json({token});
});

// Plugins
app.get("/api/plugins",(req,res)=>{
  res.json(plugins);
});

app.post("/api/plugins/submit", upload.single("file"), (req,res)=>{
  const {name,description} = req.body;
  if(!name||!description||!req.file) return res.status(400).json({message:"Incomplete"});
  pending.push({id:Date.now(),name,description,file:req.file.filename});
  res.json({message:"Submitted"});
});

// Admin (demo, no auth check here)
app.get("/api/admin/plugins/pending",(req,res)=>{
  res.json(pending);
});

app.post("/api/admin/plugins/:id/approve",(req,res)=>{
  const id = parseInt(req.params.id);
  const plugin = pending.find(p=>p.id===id);
  if(!plugin) return res.status(404).json({message:"Not found"});
  plugins.push(plugin);
  pending = pending.filter(p=>p.id!==id);
  res.json({message:"Approved"});
});

app.post("/api/admin/plugins/:id/decline",(req,res)=>{
  const id = parseInt(req.params.id);
  pending = pending.filter(p=>p.id!==id);
  res.json({message:"Declined"});
});

// Suggestion
app.post("/api/suggestions",(req,res)=>{
  const {name,topic,description} = req.body;
  console.log("Suggestion:", name, topic, description);
  res.json({message:"Suggestion received"});
});

app.listen(PORT, ()=>console.log("Sword Bot API running on",PORT));
