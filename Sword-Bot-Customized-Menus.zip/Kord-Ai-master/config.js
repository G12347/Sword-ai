


/* --- Centralized, cleaner menu builder (inserted by assistant) --- */
async function buildCleanMenu({ config, types, prefix, m, commands, version }){
  const botName = (config && typeof config === 'function' && config().BOT_NAME) ? config().BOT_NAME : "Sword";
  const ownerName = (config && typeof config === 'function' && config().OWNER_NAME) ? config().OWNER_NAME : "Owner";
  const userName = (m && m.pushName) ? m.pushName : "User";
  const uptime = (typeof process !== 'undefined' && process.uptime) ? (function(){ const s = Math.floor(process.uptime()); const h = Math.floor(s/3600); const mm = Math.floor((s%3600)/60); const ss = s%60; return `${h}h ${mm}m ${ss}s`; })() : "N/A";
  const header = `=== ${botName} ===\\nOwner: ${ownerName}\\nUser: ${userName}\\nCommands: ${commands ? commands.length : 0}\\nUptime: ${uptime}\\nVersion: v${version || '1.0.0'}\\n\\n`;
  const sections = Object.keys(types || {}).map(type => {
    const cmds = (types[type] || []).map(c => `${prefix}${String(c).replace(/[^a-zA-Z0-9-+]/g,'')}`).join(', ');
    return `${type.toUpperCase()}:\\n${cmds}`;
  }).join('\\n\\n');
  const footer = `\\nTip: Use ${prefix}menu [category] for specific commands`;
  return header + (sections || "(no categories)") + footer;
}
/* --- end menu builder --- */


// const toBool = (x) => x == 'true'
const { existsSync } = require('fs')
if (existsSync('config.env')) require('dotenv').config({ path: './config.env' })

module.exports = { 
    SESSION_ID: process.env.SESSION_ID || '',
    OWNER_NUMBER: process.env.OWNER_NUMBER || "2349067339193",
    WORKTYPE: process.env.WORKTYPE || "private",
    PREFIX: process.env.PREFIX || "[.]",
    ALWAYS_ONLINE: process.env.ALWAYS_ONLINE || true,
    MONGODB_URI: process.env.MONGODB_URI || "",
    STATUS_VIEW: process.env.STATUS_VIEW || true,
    SAVE_STATUS: process.env.SAVE_STATUS || false,
    LIKE_STATUS: process.env.SAVE_STATUS || false,
    STATUS_EMOJI: process.env.STATUS_EMOJI || "🥏",
    ERROR_MSG: process.env.ERROR_MSG || true,
    TIMEZONE: process.env.TIMEZONE || "Africa/Lagos",
    CAPTION: process.env.CAPTION || "",
    STICKER_PACKNAME: process.env.STICKER_PACKNAME || "Sword Bot",
    STICKER_AUTHOR: process.env.STICKER_AUTHOR || "🤍",
    BOT_PRESENCE: process.env.BOT_PRESENCE || "available",
    REACT: process.env.REACT || false,
    READ_MESSAGE: process.env.READ_MESSAGE || "false",
    OWNER_NAME: process.env.OWNER_NAME || "Mirage",
    BOT_NAME: process.env.BOT_NAME || "Sword Bot",
    RENDER_API_KEY: process.env.RENDER_API_KEY,
    ANTIDELETE: process.env.ANTIDELETE || "on",
    ANTIDELETE_INCHAT: process.env.ANTIDELETE_INCHAT || "off",
    ANTI_EDIT: process.env.ANTI_EDIT || "off",
    ANTI_EDIT_IN_CHAT: process.env.ANTI_EDIT_IN_CHAT || "off",
    AUDIO_DATA: process.env.AUDIO_DATA || "Sword Bot;🤍",
    SUDO: process.env.SUDO || "",
    MODS: process.env.MODS || "",
    REJECT_CALL: process.env.REJECT_CALL || "off",
    WARNCOUNT: process.env.WARNCOUNT || "4",
    LANG_CODE: process.env.LANG_CODE || "en",
    VV_CMD: process.env.VV_CMD || "👀",
    SAVE_CMD: process.env.SAVE_CMD || "📥",
    RES_TYPE: process.env.RES_TYPE || "text",
    CMD_REACT: process.env.CMD_REACT || "off",
    LOG_MESSAGES: process.env.LOG_MESSAGES || "off",
    STARTUP_MSG: process.env.STARTUP_MSG || "on",
    MENU_IMAGE: process.env.MENU_IMAGE || "",
    WELCOME_MESSAGE: process.env.WELCOME_MESSAGE ||  `╭━━━々 𝚆 𝙴 𝙻 𝙲 𝙾 𝙼 𝙴 々━━━╮
┃ ➺ *々 Welcome @user! to @gname*
┃ ➺ *々 Members: @count*
┃ ➺ We Hope You Have A Nice Time Here!
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    GOODBYE_MESSAGE: process.env.GOODBYE_MESSAGE || `╭━━━々 𝙶 𝙾 𝙾 𝙳 𝙱 𝚈 𝙴 々━━━╮
┃ ➺ *々 @user! left @gname!*
┃ ➺ *々 Members: @count*
┃ ➺ We Hope He/She Had A Nice Time Here!
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`
}