


/* --- Centralized, cleaner menu builder (inserted by assistant) --- */
async function buildCleanMenu({ config, types, prefix, m, commands, version }){
  const botName = (config && typeof config === 'function' && config().BOT_NAME) ? config().BOT_NAME : "Sword";
  const ownerName = (config && typeof config === 'function' && config().OWNER_NAME) ? config().OWNER_NAME : "Owner";
  const userName = (m && m.pushName) ? m.pushName : "User";
  const uptime = (typeof process !== 'undefined' && process.uptime) ? (function(){ const s = Math.floor(process.uptime()); const h = Math.floor(s/3600); const mm = Math.floor((s%3600)/60); const ss = s%60; return `${h}h ${mm}m ${ss}s`; })() : "N/A";
  const header = `=== ${botName} ===\\nOwner: ${ownerName}\\nUser: ${userName}\\nCommands: ${commands ? commands.length : 0}\\nUptime: ${uptime}\\nVersion: v${version || '1.0.0'}\\n\\n`;
  const sections = Object.keys(types || {}).map(type => {
    const cmds = (types[type] || []).map(c => `${prefix}${String(c).replace(/[^a-zA-Z0-9-+]/g,'')}`).join(', ');
    return `${type.toUpperCase()}:\\n${cmds}`;
  }).join('\\n\\n');
  const footer = `\\nTip: Use ${prefix}menu [category] for specific commands`;
  return header + (sections || "(no categories)") + footer;
}
/* --- end menu builder --- */


const fs = require('fs')
const path = require('path')
const rootDir = path.join(__dirname)
const modules = {}

var bin = path.join(__dirname, 'bin')

if (!fs.existsSync(bin)) {
  fs.mkdirSync(bin, { recursive: true })
}

global.bin = path.join(__dirname, 'bin')
global.strd = path.join(__dirname, 'store')

const configPath = path.join(__dirname, '..', 'config.js')
modules.config = () => require(configPath)

function processDir(dirPath) {
  const files = fs.readdirSync(dirPath)
  
  files.forEach(file => {
    const filePath = path.join(dirPath, file)
    const stats = fs.statSync(filePath)
    
    if (stats.isDirectory()) {
      processDir(filePath)
    } else if (stats.isFile() && path.extname(file) === '.js' && file !== 'index.js') {
      const mod = require(filePath)
      
      if (typeof mod === 'object') {
        for (const key in mod) {
          modules[key] = mod[key]
        }
      } else {
        const name = path.basename(file, '.js')
        modules[name] = mod
      }
    }
  })
}

processDir(rootDir)

module.exports = modules