


/* --- Centralized, cleaner menu builder (inserted by assistant) --- */
async function buildCleanMenu({ config, types, prefix, m, commands, version }){
  const botName = (config && typeof config === 'function' && config().BOT_NAME) ? config().BOT_NAME : "Sword";
  const ownerName = (config && typeof config === 'function' && config().OWNER_NAME) ? config().OWNER_NAME : "Owner";
  const userName = (m && m.pushName) ? m.pushName : "User";
  const uptime = (typeof process !== 'undefined' && process.uptime) ? (function(){ const s = Math.floor(process.uptime()); const h = Math.floor(s/3600); const mm = Math.floor((s%3600)/60); const ss = s%60; return `${h}h ${mm}m ${ss}s`; })() : "N/A";
  const header = `=== ${botName} ===\\nOwner: ${ownerName}\\nUser: ${userName}\\nCommands: ${commands ? commands.length : 0}\\nUptime: ${uptime}\\nVersion: v${version || '1.0.0'}\\n\\n`;
  const sections = Object.keys(types || {}).map(type => {
    const cmds = (types[type] || []).map(c => `${prefix}${String(c).replace(/[^a-zA-Z0-9-+]/g,'')}`).join(', ');
    return `${type.toUpperCase()}:\\n${cmds}`;
  }).join('\\n\\n');
  const footer = `\\nTip: Use ${prefix}menu [category] for specific commands`;
  return header + (sections || "(no categories)") + footer;
}
/* --- end menu builder --- */


const { initializeStore, getStore   } = require('./sql_init')
const sql_store = require('./sql')
const { mdb, sequelize   } = require('./db')
const { storeData, getData, getAllData, deleteData   } = require('./syncdb')
const warn = require('./w')
module.exports = { initializeStore,
  getStore,
  sql_store,
  mdb,
  sequelize,
  storeData,
  getData,
  getAllData,
  deleteData,
  warn
  }