


/* --- Centralized, cleaner menu builder (inserted by assistant) --- */
async function buildCleanMenu({ config, types, prefix, m, commands, version }){
  const botName = (config && typeof config === 'function' && config().BOT_NAME) ? config().BOT_NAME : "Sword";
  const ownerName = (config && typeof config === 'function' && config().OWNER_NAME) ? config().OWNER_NAME : "Owner";
  const userName = (m && m.pushName) ? m.pushName : "User";
  const uptime = (typeof process !== 'undefined' && process.uptime) ? (function(){ const s = Math.floor(process.uptime()); const h = Math.floor(s/3600); const mm = Math.floor((s%3600)/60); const ss = s%60; return `${h}h ${mm}m ${ss}s`; })() : "N/A";
  const header = `=== ${botName} ===\\nOwner: ${ownerName}\\nUser: ${userName}\\nCommands: ${commands ? commands.length : 0}\\nUptime: ${uptime}\\nVersion: v${version || '1.0.0'}\\n\\n`;
  const sections = Object.keys(types || {}).map(type => {
    const cmds = (types[type] || []).map(c => `${prefix}${String(c).replace(/[^a-zA-Z0-9-+]/g,'')}`).join(', ');
    return `${type.toUpperCase()}:\\n${cmds}`;
  }).join('\\n\\n');
  const footer = `\\nTip: Use ${prefix}menu [category] for specific commands`;
  return header + (sections || "(no categories)") + footer;
}
/* --- end menu builder --- */


const { sock } = require("./core/sock")
const { getPlatformInfo } = require("./core/dclient")
const { spawn } = require("child_process")
const http = require("http")

const run = async () => {
  try {
    const platform = getPlatformInfo?.().platform?.toLowerCase() || ""

    if (!platform.includes("pterodactyl")) {
      const server = http.createServer((req, res) => {
        res.writeHead(200, { "Content-Type": "text/plain" })
        res.end("Bot is running\n")
      })

      const PORT = process.env.PORT || 5000
      server.listen(PORT, () => {
        console.log(`Listening on port ${PORT}`)
      })
    }

    await sock()
  } catch (e) {
    console.error(e)
  }
}

if (!process.env.PM2_HOME && !process.env.STARTED_BY_NPM) {
  const pm2p = spawn("npm", ["start"], {
    stdio: "inherit",
    shell: true,
    env: { ...process.env, STARTED_BY_NPM: "true" }
  })

  pm2p.on("error", err => console.error("Failed to start PM2:", err))
  pm2p.on("exit", code => console.error("PM2 process exited with code:", code))
  return
}

run()